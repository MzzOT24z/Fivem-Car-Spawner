fx_version 'cerulean'
game 'gta5'

author 'you'
description 'Basic car spawner'
version '1.0.0'

client_script 'client.lua'
