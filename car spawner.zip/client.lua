-- Basic FiveM car spawner
-- Commands:
--   /car [model]   -> spawns the vehicle at your location and puts you in it
--   /dv            -> deletes the vehicle you're currently in (or nearest one)

local spawnedVehicles = {}

local function spawnVehicle(model)
    local modelHash = GetHashKey(model)

    if not IsModelInCdimage(modelHash) or not IsModelAVehicle(modelHash) then
        print('^1[car_spawner]^7 Invalid vehicle model: ' .. tostring(model))
        return
    end

    RequestModel(modelHash)
    local timeout = 0
    while not HasModelLoaded(modelHash) and timeout < 5000 do
        Wait(50)
        timeout = timeout + 50
    end

    if not HasModelLoaded(modelHash) then
        print('^1[car_spawner]^7 Failed to load model: ' .. tostring(model))
        return
    end

    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)

    -- offset spawn point slightly in front of the player
    local offsetCoords = GetOffsetFromEntityInWorldCoords(ped, 0.0, 5.0, 0.0)

    local vehicle = CreateVehicle(modelHash, offsetCoords.x, offsetCoords.y, coords.z, heading, true, false)
    SetVehicleOnGroundProperly(vehicle)
    SetPedIntoVehicle(ped, vehicle, -1)
    SetVehicleNumberPlateText(vehicle, 'SPAWNED')

    -- set fuel to full if the resource has a fuel decorator (basic games ignore this safely)
    SetVehicleFuelLevel(vehicle, 100.0)

    table.insert(spawnedVehicles, vehicle)
    SetModelAsNoLongerNeeded(modelHash)
end

local function deleteNearestVehicle()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)

    if vehicle == 0 then
        -- not in a vehicle, try to find the closest spawned one
        local coords = GetEntityCoords(ped)
        local closest, closestDist = nil, 10.0
        for i = #spawnedVehicles, 1, -1 do
            local v = spawnedVehicles[i]
            if DoesEntityExist(v) then
                local dist = #(coords - GetEntityCoords(v))
                if dist < closestDist then
                    closest = v
                    closestDist = dist
                end
            else
                table.remove(spawnedVehicles, i)
            end
        end
        vehicle = closest
    end

    if vehicle and DoesEntityExist(vehicle) then
        SetEntityAsMissionEntity(vehicle, true, true)
        DeleteVehicle(vehicle)
    else
        print('^3[car_spawner]^7 No nearby vehicle to delete.')
    end
end

RegisterCommand('car', function(source, args)
    local model = args[1]
    if not model then
        print('^3[car_spawner]^7 Usage: /car [model name], e.g. /car adder')
        return
    end
    spawnVehicle(model)
end, false)

RegisterCommand('dv', function(source, args)
    deleteNearestVehicle()
end, false)
